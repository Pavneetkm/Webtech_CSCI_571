package com.example.pavneetkaur.myapplication;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by pavneetkaur on 12/1/16.
 */

public class Aboutme extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.about);

    }



}
